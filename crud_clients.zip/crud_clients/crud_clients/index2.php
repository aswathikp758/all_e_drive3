<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients</title>
</head>
<body>

</body>
</html>
<?php
$link = mysqli_connect("localhost", "root", "", "database");
 

if($link === false){
    die("Could not connect");
}


function get_all_data($conn){
    
    $get_data = mysqli_query($conn, " SELECT * FROM clients ");
    if(mysqli_num_rows($get_data) > 0){
        echo '<table>
              <tr>
                <th>name</th>
                <th>Email</th> 
                <th>address</th> 
                <th>action</th> 

              </tr>';
              
        while($row = mysqli_fetch_array($get_data)){
           
            echo '<tr>
            <td>'.$row['name'].'</td>
            <td>'.$row['email'].'</td>
            <td>'.$row['address'].'</td>
            <td>
            <a href="update.php?id='.$row['id'].'">Edit</a>&nbsp;|   
            <a href="delete.php?del='.$row['id'].'">Delete</a>
            </td>
            </tr>';

        }
        echo '</table>';
    }else{
        echo "<h3>No records found. Please insert some records</h3>";
    }
}

?>