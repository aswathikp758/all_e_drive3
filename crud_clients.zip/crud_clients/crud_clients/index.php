
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients</title>
</head>
<body>
    <?php 
    get_all_data($link);
    ?>
</body>
</html>

<?php
$link = mysqli_connect("localhost", "root", "", "web");
 if($link === false){
    die("Could not connect");
}


function get_all_data($link){
    
    $get_data = mysqli_query($link, "SELECT * FROM demo");
    if(mysqli_num_rows($get_data) > 0){
        echo '<table>
              <tr>
                <th>name</th>
                <th>Email</th> 
                <th>address</th> 
                <th>action</th> 

              </tr>';
              
        while($row = mysqli_fetch_array($get_data)){
           
            echo '<tr>
            <td>'.$row['first_name'].'</td>
            <td>'.$row['last_name'].'</td>
            <td>'.$row['email'].'</td>
            <td>
            <a href="update.php?id='.$row['id'].'">Edit</a>&nbsp;|   
            <a href="delete.php?del='.$row['id'].'">Delete</a>
            </td>
            </tr>';

        }
        echo '</table>';
    }else{
        echo "<h3>No records found. Please insert some records</h3>";
    }
}

?>
