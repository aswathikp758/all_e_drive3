<?php
require 'db_connection.php';

if(isset($_GET['id'])){
    
    $userid = $_GET['id'];
    $get_user = mysqli_query($conn,"SELECT * FROM `users` WHERE id='$userid'");
    
    if(mysqli_num_rows($get_user) === 1){
        
        $row = mysqli_fetch_array($get_user);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update data</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
     <div class="container">
      
       <!-- UPDATE DATA -->
       
        <div class="form">
            <h2>Update Data</h2>
            <form action="" method="post">
                <strong>Username</strong><br>
                <input type="text"  name="username" placeholder="Enter your full name" value="<?php echo $row['username'];?>" required><br>
                <strong>Email</strong><br>
                <input type="email"  name="user_email" placeholder="Enter your email" value="<?php echo $row['user_email'];?>" required><br>
                <input type="submit" value="Update">
            </form>
        </div>
        <!-- END OF UPDATE DATA SECTION -->
    </div>
</body>
</html>
<?php

    }else{
        
        echo "<h1>error in while uploading file</h1>";
    }
    
}else{
    
    echo "<h1>error</h1>";
}


/* ---------------------------------------------------------------------------
------------------------------------------------------------------------------ */


// UPDATING DATA

if(isset($_POST['username']) && isset($_POST['user_email'])){
          
        
        $username =$_POST['username'];
        $user_email =$_POST['user_email'];
        
                       
                // UPDATE USER DATA 
                             
                $update_query = mysqli_query($conn,"UPDATE `users` SET username='$username',user_email='$user_email' WHERE id=$userid");

                if($update_query){
                    
                    header('location:index.php');
                    
                }else{
                    echo "<h3>Opps something wrong!</h3>";
                }
          } ?>

