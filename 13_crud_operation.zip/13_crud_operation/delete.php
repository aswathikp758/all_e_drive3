<?php
require 'db_connection.php';
if(isset($_GET['del'])){
    
    $userid = $_GET['del'];
    $delete_user = mysqli_query($conn,"DELETE FROM `users` WHERE id='$userid'");
    
    if($delete_user){
        echo "<script>
        alert('Data Deleted');
        window.location.href = 'index.php';
        </script>";
        exit;
    }else{
       echo "Opps something wrong!"; 
    }
}else{
    
    
    echo "<h1>error</h1>";
}
?>