<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="post" action="ses2.php">
<table border="5">
<tr><td>Username</td><td><input type="text" name="name"></td></tr>
<tr><td>Password</td><td><input type="Password" name="pw"></td></tr>
<tr><td colspan="2"><center><input type="submit" name="submit" ></center></td></table></tr>
</form>
</body>
</html>