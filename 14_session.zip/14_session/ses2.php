<?php
$u=$_REQUEST['name'];
$p=$_REQUEST['pw'];

if ((($u=='admin')&&($p=='work')) || (($u=='user')&&($p=='1pass')))
 {
 	session_start();
	$_SESSION['test']=$u;
	
	echo "Session is working<br/>";
	echo"Nov 6, 2019 - Learn how to create HTML hyperlinks. This guide covers the ... The anchor element tag is the letter “a” surrounded by angle bracketsov 6, 2019 - Learn how to create HTML hyperlinks. This guide covers the ... The anchor element tag is the letter “a” surrounded by angle bracketsov 6, 2019 - Learn how to create HTML hyperlinks. This guide covers the ... The anchor element tag is the letter “a” surrounded by angle brackets like this: <a> . Both the ... See all Red roducts available in Large</a>.<br><br><br>";
	
echo "<a href='ses3.php'>Logout</a>";
// remove all session variables
session_unset();

// destroy the session
session_destroy();
}
 else
    {
	echo "invalid password or username <br><br>";
	
	echo "<a href='ses1.php'>please Re-try</a>";

    }
 ?>