<?php

echo "Logout Successfully<br/>";
echo "<a href='ses1.php'>Try Again</a>";

?>