<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<?php

$id=$_GET['id'];
	$sno=$_GET['sno'];

?>	<h1 align=center >Ticket booking</h1>
					
							<form  method="POST" >

								<table align="center" width="600" height="400">
									
										<tr>
										<td>Seat no</td>
										<td><input type="text" name="bus" value="<?php echo $sno;?>" readonly></td>
									</tr><tr>
										<td>Name</td>
										<td><input type="text" name="name" required>
										</td>
									</tr>
									<tr>
										<td>Phone No.</td>
										<td><input type="number" name="Phno"  maxlength="10">
										</td>
									</tr>
									<tr>
										<td>Email</td>
										<td><input type="text" name="email"  required>
										</td>
									</tr>
									
									<tr>
										<td>boarding from</td>
										<td><input type="text" name="bfrom" required>
										</td>
									</tr>
									<tr>
										<td>Boarding to</td>
										<td><input type="text" name="bto" required>
										</td>
									</tr>
									<tr>
										<td></td>
										<td><input type="submit" name="submit" value="Book"> 
											
										</td>
									</tr>

								</table>

							</form>
							<?php
								
								
						
								if(isset($_POST['submit']))
								{
									$name=$_POST['name'];
									
									$phno=$_POST['Phno'];
									$email=$_POST['email'];
									
									$bfrom=$_POST['bfrom'];
									$bto=$_POST['bto'];
									$con=mysqli_connect("localhost","root","","buss");
									
$str1="UPDATE `bus` SET `status`='booked',`name`='$name',`email`='$email',`phone`='$phno',`bfrom`='bfrom',`bto`='bto' WHERE id='$id'";
									$exe=mysqli_query($con,$str1);
									
								
							if($exe)
							{
								
								?>
								<script>
									alert("booking success");
									window.location.assign("INDEX.php");
								</script>
								<?php
							}
							else{
								?>
								<script>
									alert("error");
									window.location.assign("INDEX.php");
									</script>
									
								<?php
							}
										}
										
											?>
								
					


</body>
</html>