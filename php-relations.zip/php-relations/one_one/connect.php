
<?php
$link = mysqli_connect("localhost", "root", "", "country_db");
 
if($link === false){
    die("Could not connect");
}
 
$sql = "SELECT country.cid, country.country,capital.capital
FROM country
INNER JOIN capital ON country.cid = capital.ca_id";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){

       echo "<table>";
            echo "<tr>";
                echo "<th>id</th>";
                echo "<th>Country</th>";
                echo "<th>Capital</th>";
                
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['cid'] . "</td>";
                echo "<td>" . $row['country'] . "</td>";
                echo "<td>" . $row['capital'] . "</td>";
                echo "</tr>";
        }
        echo "</table>";
            } 

            else{
        echo "No records matching your query were found.";
                 }
} 

else{
    echo "Could not able to execute" . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>