
<?php
$link = mysqli_connect("localhost", "root", "", "newdata");
 
if($link === false){
    die("Could not connect");
}
 
$sql = "SELECT employee.emp_id, employee.emp_name,salary_slips.total_slry,salary_slips.month,salary_slips.year,salary_slips.issue_date
FROM employee
INNER JOIN salary_slips ON employee.sid = salary_slips.s_id";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){

       echo "<table>";
            echo "<tr>";
                echo "<th>id</th>";
                echo "<th>Employee name</th>";
                echo "<th>Salary</th>";
                echo "<th>Month</th>";
                echo "<th>Year</th>";
                 echo "<th>Issue date</th>";
                
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['emp_id'] . "</td>";
                echo "<td>" . $row['emp_name'] . "</td>";
                echo "<td>" . $row['total_slry'] . "</td>";
                 echo "<td>" . $row['month'] . "</td>";
                  echo "<td>" . $row['year'] . "</td>";
                   echo "<td>" . $row['issue_date'] . "</td>";
                echo "</tr>";
        }
        echo "</table>";
            } 

            else{
        echo "No records matching your query were found.";
                 }
} 

else{
    echo "Could not able to execute" . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>