
<?php
$link = mysqli_connect("localhost", "root", "", "employee_db");
 
if($link === false){
    die("Could not connect");
}
 
$sql = "SELECT employee.emp_name,duty_shifts.duty_shift
FROM employee
INNER JOIN duty_shifts ON employee.emp_id = duty_shifts.empid";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){

       echo "<table>";
            echo "<tr>";
               
                echo "<th>Employee name</th>";
                echo "<th>Duty Shift</th>";
                
                
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['emp_name'] . "</td>";
                echo "<td>" . $row['duty_shift'] . "</td>";
                echo "</tr>";
        }
        echo "</table>";
            } 

            else{
        echo "No records matching your query were found.";
                 }
} 

else{
    echo "Could not able to execute" . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>