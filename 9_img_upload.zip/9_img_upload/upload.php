<?php
if(isset($_POST['submit'])){
    if(($_FILES["photo"]) && $_FILES["photo"]["error"] == 0){
        $filename = $_FILES["photo"]["name"];
        $filetype = $_FILES["photo"]["type"];
        $filesize = $_FILES["photo"]["size"];
        $file_path =$_FILES["photo"]['tmp_name'];

    
        if($filename!="" && ($filetype="image/jpeg"||$filetype="image/png"||$filetype="image/gif")&& $filesize<=914400)
        
            if(file_exists("upload/" . $filename)){
                echo $filename . " is already exists.";
            } else {
                move_uploaded_file($file_path,'upload/'.$filename);
               
                echo "Your file was uploaded successfully.";
                
            } 
         else{
            echo "There was a problem uploading your file"; 
        }
    } 
    else{
        echo " " . $_FILES["photo"]["error"];
    }
}
?>