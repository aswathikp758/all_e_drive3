<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>File Upload Form</title>
</head>
<body>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <h2>Upload File</h2>
        <input type="file" name="photo">
        <input type="submit" name="submit" value="Upload">
            </form>
</body>
</html>