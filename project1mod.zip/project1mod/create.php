<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="container">

        <h2>Please Enter Product Details</h2>
    </div>
    <div class="wrapper">
        <form action="" method="Post" enctype='multipart/form-data'>
            <label>Item Name:</label>
            <input type="text" id="itemname" name="itemname"><br>
            <label>Item Code:</label>
            <input type="text" id="itemcode" name="itemcode"><br>
            <label>Quantity:</label>
            <input type="text" id="quantity" name="quantity"><br>
            <label>Image:</label>
            
            <input type="file" name="file" >
  <span style="font-size:12px;">Only jpg / jpeg/ png /gif format allowed.</span>  <br>
            <input type="submit" value="Submit" name='submit'>
        </form>
    </div>

</body>

</html>
<?php
$conn = mysqli_connect("localhost", "root", "", "tutorial");
 
if($conn === false){
    die("Could not connect");
}

if(isset($_POST['submit'])){
    $itemname =$_REQUEST['itemname'];
    $itemcode =$_REQUEST['itemcode'];
    $quantity =$_REQUEST['quantity'];
    $image = $_FILES['file']['name'];
    $target_dir = "upload/";
    $extensions_arr = array("jpg","jpeg","png","gif");

    $sql = "INSERT INTO products2 (itemname, itemcode, quantity,images) VALUES ('$itemname ', '$itemcode', '$quantity', '$image')"; 
    
    move_uploaded_file($_FILES['file']['tmp_name'],'upload/'.$image);

    if(mysqli_query($conn, $sql)){
        echo "Records added successfully.";
        header("location:index.php");
    }
     else{
        echo "Could not able to execute  " . mysqli_error($conn);
    }


}

// close connection
mysqli_close($conn);
?>