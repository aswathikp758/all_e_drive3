<?php
$conn = mysqli_connect("localhost", "root", "", "tutorial");
 

if($conn === false){
    die("Could not connect");
}

if(isset($_GET['id'])){
    
    $productsid = $_GET['id'];
    $get_data = mysqli_query($conn,"SELECT * FROM products2 WHERE id='$productsid'");
    
    if(mysqli_num_rows($get_data) === 1){
        
    $row = mysqli_fetch_array($get_data);
    $filename = $row['images'];
?>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update data</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <!-- UPDATE DATA -->
    <div class="container">

        <h2>Update Product</h2>
    </div>
    <div class="container-update">

        <form action="" method="post" enctype='multipart/form-data'>
            <strong>Item Name</strong><br>
            <input type="text" name="itemname" placeholder="Enter your itemname " value="<?php echo $row['itemname'];?>"
                required><br>
            <strong>Item Code</strong><br>
            <input type="text" name="itemcode" placeholder="Enter your itemcode " value="<?php echo $row['itemcode'];?>"
                required><br>
            <strong>Quantity</strong><br>
            <input type="text" name="quantity" placeholder="Enter your quantity " value="<?php echo $row['quantity'];?>"
                required><br>
            <strong>Image</strong><br>
            <img src="upload/<?=$filename?>" width="300px" height="300px">
            <br>
             <input type="file" name="file" >
         <span style="font-size:12px;">Only jpg / jpeg/ png /gif format allowed.</span>  <br>
            <input type="submit" value="Update">
        </form>
    </div>
</body>

</html>
<?php

    }else{
        
        echo "<h1>error in while uploading file</h1>";
    }
    
}else{
    
    echo "<h1>error</h1>";
}


/* ---------------------------------------------------------------------------
------------------------------------------------------------------------------ */


// UPDATING DATA

if(isset($_POST['itemname']) && isset($_POST['itemcode']) && isset($_POST['quantity']) && isset($_FILES['file']['name'])){
          
        
        $itemname =$_POST['itemname'];
        $itemcode =$_POST['itemcode'];
        $quantity =$_POST['quantity'];
        $image   = $_FILES['file']['name'];
        $target_dir = "upload/";
        $extensions_arr = array("jpg","jpeg","png","gif");
                       
                // UPDATE USER DATA 
                             
                $update_query = mysqli_query($conn,"UPDATE products2 SET itemname='$itemname',itemcode='$itemcode',quantity='$quantity',images='$image' WHERE id=$productsid");

                
                if($update_query){
                    
                    header('location:index.php');
                    
                }else{
                    echo "<h3>Opps something wrong!</h3>";
                }
           
                
                
            }
            
            
        
?>