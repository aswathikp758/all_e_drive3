<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products </title>
    <link rel="stylesheet" href="style.css">
</head>    
<body>
    
   <div class="container">
   	
   	<h2>Delete Product</h2>  	
   </div>   

      
</body>

</html>
<?php
$conn = mysqli_connect("localhost", "root", "", "tutorial");
 

if($conn === false){
    die("Could not connect");
}
if(isset($_GET['del'])){
    
    $products2id = $_GET['del'];
    $delete_products2 = mysqli_query($conn,"DELETE FROM `Products2` WHERE id='$products2id'");
    
    if($delete_products2){
        echo "<script>
        alert('Data Deleted');
        window.location.href = 'index.php';
        </script>";
        exit;
    }else{
       echo "Opps something wrong!"; 
    }
}else{
    
    
    echo "<h1>error</h1>";
}
?>