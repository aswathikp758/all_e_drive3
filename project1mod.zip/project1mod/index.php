<?php
$conn = mysqli_connect("localhost", "root", "", "tutorial");
 

if($conn === false){
    die("Could not connect");
}

// function for getting data from database
function get_all_data($conn){
    
    $get_data = mysqli_query($conn,"SELECT * FROM products2 ");
    if(mysqli_num_rows($get_data) > 0){
        echo '<table>
                <tr>
                <th>itemname</th>
                <th>itemcode</th>
                <th>quantity</th>
                <th>image</th> 
                <th>Action</th> 
              </tr>';
              
        while($row = mysqli_fetch_array($get_data)){
           
            echo '<tr>
            <td>'.$row['itemname'].'</td>
            <td>'.$row['itemcode'].'</td>
            <td>'.$row['quantity'].'</td>
            <td>'.$row['images'].'</td>
            <td>
            <a href="update.php?id='.$row['id'].'">Edit</a>&nbsp;|   
            <a href="delete.php?del='.$row['id'].'">Delete</a>
            </td>
            </tr>';

        }
        echo '</table>';
    }else{
        echo "<h3>No records found. Please insert some records</h3>";
    }
}


?>
<!DOCTYPE html>
<html lang="">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>products</title>
    <link rel="stylesheet" href="style.css">
</head>    
<body>
       <div class="container">
    
    <h2>Products</h2>   
   </div>   
   <br>

      <a href="create.php" class="button button1">Add New Products</a>
    
      
    
        <h2>Show Data</h2>
        <?php 
        // calling get_all_data function
        get_all_data($conn); 
        ?>
        <!-- END OF SHOW DATA SECTION -->
    
</body>

</html>