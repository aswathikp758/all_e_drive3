<?php
$link = mysqli_connect("localhost", "root", "", "demo");

if($link === false){
    die("Could not connect");
}
 
$sql = "SELECT * FROM users LIMIT 2";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table>";
            echo "<tr>";
                echo "<th>id</th>";
                echo "<th>name</th>";
                echo "<th>age</th>";
                echo "<th>email</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['age'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
    } else{
        echo "No records found.";
    }
} else{
    echo "ERROR: Could not able to execute" . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>