<?php

$link = mysqli_connect("localhost", "root", "", "demo");

if($link === false){
    die("Could not connect");
}
 
$sql = "SELECT * FROM users WHERE name='sachin' or location='calicut' "; //name='sachin' and location='calicut'"

if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table border='1'>";
            echo "<tr>";
                echo "<th>id</th>";
                echo "<th>name</th>";
                echo "<th>age</th>";
                echo "<th>email</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['age'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
    } else{
        echo "No records matching found.";
    }
} else{
    echo "Could not able to execute " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);






/*select *  from users  where age = 44;

select *  from img where name = 'vimal'  and id < 9 ;

select *  from img where name = 'vimal'  or id < 9;

select *  from img  where id between 1 and 3;


select *  from img  where address = 'calicut'  order by name ASC;

select *  from img  where address = 'calicut'  order by name DESC;
*/
?>
