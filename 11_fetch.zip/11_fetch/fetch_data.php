<?php
$link = mysqli_connect("localhost", "root", "", "web");
 
if($link === false){
    die("Could not connect");
}
 
$sql = "SELECT * FROM demo";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){

       echo "<table>";
            echo "<tr>";
                echo "<th>id</th>";
                echo "<th>name</th>";
                echo "<th>last_name</th>";
                echo "<th>email</th>";
            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['first_name'] . "</td>";
                echo "<td>" . $row['last_name'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
            } 

            else{
        echo "No records matching your query were found.";
                 }
} 

else{
    echo "Could not able to execute" . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>



for($i=1;$i<10;$i++)
{
    echo"$i";
}