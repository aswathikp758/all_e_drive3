
<?php
$n=$_GET["username"];
$e=$_GET["bloodgroup"];

echo "Welcome: $n";
echo "<br>";
echo "your bloodgroup is: $e";


?>
