<?php  
$n=$_POST["name"];


//receiving name field value in $name variable  
$e=$_REQUEST["email"];

//receiving password field value in $password variable  
 //PHP provides the superglobal variable $_GET to access all the information sent either through the URL or submitted through an HTML form using the method="get" 
echo "Welcome: $n";
echo "<br>";
echo "your email is: $e";  
?> 

