<html>  
   <body>  
     
      <form action = "welcomeget.php" method = "GET">  
         Username: <input type = "text" name = "username" /> <br>  
         Blood Group: <input type = "text" name = "bloodgroup" /> <br>  
         <input type = "submit" />  
      </form>  
        
   </body>  
</html>
