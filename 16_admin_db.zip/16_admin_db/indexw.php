<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/admin_login.css">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<title>Admin Panel</title>
</head>
<body > 		

<div class=" container-fluid">
<h5 align="center" style="margin-top:0px; color:#0F0;font-size:18px; font-style:italic; font-family:Arial, Helvetica, sans-serif; font-weight:600;"> Admin Login</h5><br>
<div align="center" class="login">
    <form name="form" action="do_adminpanel.php" method="post" align="center" style="margin-top:px;width:25%; height:100%;" >
        <div class="form-group">
            <label  style="font-size:12px; font-style:normal; font-style:italic;">User Name</label>            
            <input type="Text" class="form-control"  placeholder="User Name" name="username">
        </div>
        <div class="form-group">
            <label for="inputPassword" style="font-size:12px; font-style:normal; font-style:italic;">Password</label>
              <input type="password" class="form-control"  placeholder="Password" name="password">
        </div>
        <button type="submit" value="login" class="btn btn-primary" name="submit">Log In</button></form>
   
  </div>
</div>
</body>
</html>
