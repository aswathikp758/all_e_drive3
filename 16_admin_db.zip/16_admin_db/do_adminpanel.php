<?php
$link = mysqli_connect("localhost", "root", "", "demo");
 
if($link === false){
    die("Could not connect");
}

 
$username =$_REQUEST['username'];
$password =$_REQUEST['password'];

 $sql= "SELECT * FROM login WHERE username = '$username' AND password = '$password' ";
 $result = mysqli_query($link,$sql); 
 $check = mysqli_fetch_array($result); 
 if(isset($check))
 { 
header('location:grid.php');
  }
 else{ 
 	echo 'invalid username or password';  } 

// close connection
mysqli_close($link);
?>