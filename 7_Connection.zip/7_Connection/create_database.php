<?php
$con = mysqli_connect("localhost", "root", "");
 
if($con === false){
    die("could not connect");
    }
 
$sql = "CREATE DATABASE web";

    if(mysqli_query($con, $sql)){
    echo "Database created successfully";
    } 
    else{
    echo "Could not able to execute database. " . mysqli_error($con);
    }
 
// Close connection
mysqli_close($con);

?>