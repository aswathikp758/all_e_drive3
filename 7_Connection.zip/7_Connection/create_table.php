<?php
$link = mysqli_connect("localhost", "root", "", "web");
 

if($link === false){
    die("Could not connect");
}
 
$sql = "CREATE TABLE demo(
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(30) NOT NULL,
    last_name VARCHAR(30) NOT NULL,
    email VARCHAR(70) NOT NULL 
)";
if(mysqli_query($link, $sql)){
    echo "Table created successfully.";
} else{
    echo "Could not able to execute  " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>