<?php
$link = mysqli_connect("localhost", "root", "", "web");
 

if($link === false){
    die("Could not connect");
}
?>