<?php

$link = mysqli_connect("localhost", "root", "", "web");
 

if($link === false){
    die("Could not connect");
}
 
$sql = "INSERT INTO demo ( first_name, last_name, email) VALUES ('admin', 'k', 'admin@gmail.com')";

if(mysqli_query($link, $sql)){
    echo "Data inserted successfully.";
} else{
    echo "Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>




  