<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<?php
require("header.php");
?>

<h1>welcome</h1>

<?php
require("gallery.php");
require("body.php");
?>

</body>
</html>









