<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script></head>
<body>
	<style type="text/css">
		.div{
			background-color: grey;
			height: auto;
			width: auto;
			text-align: justify-all;
		}
	</style>

<div class="div">
	

<?php require 'navbar.php';  

 require 'sidbar.php'; ?>


<div class="container-fluid">
	<div class="container">
		<br>
  <img class="img-responsive" src="handi3.jpg"> 
</div>


<h1><center><i>Welcome to my home page!</i></center></h1>
<p>Website.com was started up in 2005 by a group of guys who have worked in the web hosting industry for years. They realized that there was one thing that plagued traditional web hosting services: usability. Traditional web hosting services were simply too complicated and too difficult for an average person to use. They agreed that making websites should be fun, fast, and easy.

<p>Website.com was started up in 2005 by a group of guys who have worked in the web hosting industry for years. They realized that there was one thing that plagued traditional web hosting services: usability. Traditional web hosting services were simply too complicated and too difficult for an average person to use. They agreed that making websites should be fun, fast, and easy.

So, they started to develop their own website builder software with these goals in mind. After years of testing and development, they launched this version of Website.com that you see today.</p>

<p>Website.com was started up in 2005 by a group of guys who have worked in the web hosting industry for years. They realized that there was one thing that plagued traditional web hosting services: usability. Traditional web hosting services were simply too complicated and too difficult for an average person to use. They agreed that making websites should be fun, fast, and easy.

So, they started to develop their own website builder software with these goals in mind. After years of testing and development, they launched this version of Website.com that you see today.</p>

<p>Website.com was started up in 2005 by a group of guys who have worked in the web hosting industry for years. They realized that there was one thing that plagued traditional web hosting services: usability. Traditional web hosting services were simply too complicated and too difficult for an average person to use. They agreed that making websites should be fun, fast, and easy.

So, they started to develop their own website builder software with these goals in mind. After years of testing and development, they launched this version of Website.com that you see today.</p>

<p>Website.com was started up in 2005 by a group of guys who have worked in the web hosting industry for years. They realized that there was one thing that plagued traditional web hosting services: usability. Traditional web hosting services were simply too complicated and too difficult for an average person to use. They agreed that making websites should be fun, fast, and easy.

So, they started to develop their own website builder software with these goals in mind. After years of testing and development, they launched this version of Website.com that you see today.</p>
<img>

</div>
<!--The include_once and require_once statements will only include the file once even if asked to include it a second time i.e. if the specified file has already been included in a previous statement, the file is not included again. 
-->	 

 <?php require 'footer.php';?>

</body>
</html>

