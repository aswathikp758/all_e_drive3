<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.footer{
			background-color: black;
			text-align: center;
			color: white;
		}
	</style>
</head>
<body>
<footer class="footer">copyright@bigleap.com</footer>
</body>
</html>