<!Doctype html>
<html>
<head>
    <?php
    include("config.php");
 
    if(isset($_POST['but_upload'])){
        $name = $_FILES['file']['name'];
        $target_dir = "upload/";
        $extensions_arr = array("jpg","jpeg","png","gif");
            // Insert record
        $query = "insert into images(path) values('".$name."')";
           
        mysqli_query($con,$query) or die(mysqli_error($con));
            
         // Upload file
        move_uploaded_file($_FILES['file']['tmp_name'],'upload/'.$name);

        if($query){
        echo "image upload succesfully<br>";
         }
        else
       {
        echo "error";
       }
    }
    
    ?>
<body>
    <form method="post" action="" enctype='multipart/form-data'>
        <input type='file' name='file' />
        <input type='submit' value='Save name' name='but_upload'>
        
    </form>

</body>
</html>
