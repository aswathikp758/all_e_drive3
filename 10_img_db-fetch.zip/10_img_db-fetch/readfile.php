<?php 

include "config.php";

$images_sql = "SELECT * FROM images ORDER BY id desc";

$result = mysqli_query($con,$images_sql);

$row = mysqli_fetch_array($result);

$filename = $row['path'];
?>
<!DOCTYPE html>
<html>
<head></head>
<body>

	<!-- Image -->
	<img src="upload/<?= $filename ?>" width="300px" height="300px">



<?php 
echo($filename);
?>
	
</body>
</html>


