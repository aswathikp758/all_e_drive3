<?php
$link = mysqli_connect("localhost", "root", "", "web");
 
if($link === false){
    die("Could not connect");
}
 
$f_name =$_REQUEST['first_name'];
$l_name =$_REQUEST['last_name'];
$email =$_REQUEST['email'];
 
$sql = "INSERT INTO demo (first_name, last_name, email) VALUES ('$f_name', '$l_name', '$email')";  

if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
}
 else{
    echo "Could not able to execute  " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>