<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Records Form</title>
</head>
<body>
<form action="insert.php" method="post">
	<p>
    	<label >First Name:</label>
        <input type="text" name="first_name">
    </p>
    <p>
    	<label>Last name</label>
        <input type="text" name="last_name">
    </p>
    <p>
    	<label>Email Address:</label>
        <input type="text" name="email">
    </p>
    <input type="submit" value="Add Records">
</form>
</body>
</html>
